package kendaraan.util;

public interface ShootAble {
    void Shoot(String vehicle);
}
